#include <stdlib.h>
#include <stdio.h>
using namespace std;
#include "dll_node.h"
#include "cache_dll.h"


cache_dll :: cache_dll(){
    head = nullptr;
    tail = nullptr;
}

void cache_dll :: add_block(cache_block* new_block) {
    dll_node* new_node = new dll_node(new_block);
    if (head == nullptr) {
        head = new_node;
        tail = new_node;
    } else {
        head->prev = new_node;
        new_node->next = head;
        head = new_node;
    }
}

void cache_dll :: remove_block() {
    if (tail != nullptr) {
        dll_node* temp = tail;
        if (tail->prev != nullptr) {
            tail = tail->prev;
            tail->next = nullptr;
        } else {
            head = nullptr;
            tail = nullptr;
        }
        delete temp;
    }
}


