#include <stdlib.h>
#include <stdio.h>
using namespace std;
#include "cache_block.h"
#include "dll_node.h"


dll_node :: dll_node(cache_block* block){
    this->block = block;
    this->prev = nullptr;
    this->next = nullptr; 
}

dll_node :: ~dll_node(){
    delete block;
}

