#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
#include "cache_set.h"
#include "sim.h"
using namespace std;

class cache{
    private:
    unordered_map<uint32_t, cache_set*> sets;
    cache_config_t config;
    cache_bit_info_t bit_info;
    public:
    cache(cache_config_t);
    void cache_read(uint32_t);
    void cache_write(uint32_t);
};  