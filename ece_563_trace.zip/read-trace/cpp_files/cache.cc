#include <stdlib.h>
#include <stdio.h>
using namespace std;
#include "cache.h"
#include "sim.h"
#include "cache_set.h"
#include "cache_block.h"
#include <bits/stdc++.h>

cache :: cache (cache_config_t input_params) {
    config.INDEX = input_params.SIZE / (input_params.BLOCKSIZE * input_params.ASSOC);
    config.BLOCKSIZE = input_params.BLOCKSIZE;
    config.ASSOC = input_params.ASSOC;    
    config.SIZE = input_params.SIZE;

    bit_info.INDEX_BITS = log2(config.INDEX);
    bit_info.OFFSET_BITS = log2(config.BLOCKSIZE);
    bit_info.TAG_BITS = ADDRESS_LENGTH - bit_info.INDEX_BITS - bit_info.OFFSET_BITS;
} 

void cache :: cache_write(uint32_t addr){
    uint32_t index = (addr >> bit_info.OFFSET_BITS) & ((1 << bit_info.INDEX_BITS) - 1);
    uint32_t tag = addr >> (bit_info.OFFSET_BITS + bit_info.INDEX_BITS);

    if(sets.find(index) != sets.end()){
        if(sets[index]->check_tag(tag)){
            cache_block* tempblock = sets[index]->get_block(tag);
            sets[index]->update_order(tempblock->get_counter());
            tempblock->mark_dirty();
        } else {
            sets[index]->add_line(tag);
            sets[index]->mark_dirty(tag);
        }
    } else {
        sets[index] = new cache_set(index, config.ASSOC);
        sets[index]->add_line(tag);
        sets[index]->mark_dirty(tag);
    }

}


void cache :: cache_read(uint32_t addr){
    uint32_t index = (addr >> bit_info.OFFSET_BITS) & ((1 << bit_info.INDEX_BITS) - 1);
    uint32_t tag = addr >> (bit_info.OFFSET_BITS + bit_info.INDEX_BITS);

    if(sets.find(index) != sets.end()){
        if(sets[index]->check_tag(tag)){
            cache_block* tempblock = sets[index]->get_block(tag);
            sets[index]->update_order(tempblock->get_counter());
        } else {
            sets[index]->add_line(tag);
        }
    } else {
        sets[index] = new cache_set(index, config.ASSOC);
        sets[index]->add_line(tag);
    }
}

cache :: ~cache(){
    for(auto& set : sets){
        delete set.second;
    }
}