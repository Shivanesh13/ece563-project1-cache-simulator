
#include <stdlib.h>
#include <stdio.h>
using namespace std;

class dll_node{
    public:
        cache_block* block;
        dll_node* prev;
        dll_node* next;
        dll_node(cache_block* block);
        ~dll_node();
};