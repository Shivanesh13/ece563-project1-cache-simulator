#include <stdlib.h>
#include <stdio.h>
using namespace std;
#include "cache_block.h"
#include "cache_set.h"

cache_set :: cache_set(uint32_t index, uint32_t num_sets) : index(index), num_sets(num_sets) {
    active_blocks = 0;
    for (uint32_t i = 0; i < num_sets; i++)
    {
        cache_block* new_block = new cache_block(0);
        new_block->set_counter(i);
        blocks.push_back(new_block);
    }
}

cache_set :: ~cache_set(){
    for(auto& block : blocks){
        delete block;
    }
}

bool cache_set :: check_tag(uint32_t tag) {
    for (auto block : blocks) {
        if (block->check_tag(tag) && block->is_valid()) {
            return true;
        }
    }
    return false;
}

void cache_set :: update_order(uint32_t counter){
    for(auto& block : blocks){
        if(block->get_counter() < counter){
            block->set_counter(block->get_counter() + 1);
        } else if(block->get_counter() == counter){
            block->set_counter(0);
        } 
    }
}

void cache_set :: mark_dirty(uint32_t tag){
    for(auto& block : blocks){
        if(block->check_tag(tag)){
            block->mark_dirty();
            return;
        }
    }
}

cache_block* cache_set :: get_block(uint32_t tag){
    for (auto block : blocks) {
        if (block->check_tag(tag)) {
            return block;
        }
    }
    return nullptr;
}

bool cache_set :: add_line(uint32_t tag) {
    for(auto& block : blocks){
        if(block->get_counter() == num_sets-1){
            block->evict();
            block->set_tag(tag);
            block->mark_clean();
            block->mark_valid();
            update_order(num_sets-1);
            return true;
        }
    }
    return false;
}



